import { createContext } from "react";

export const SelectedYearContext = createContext();
