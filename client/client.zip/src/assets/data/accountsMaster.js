export const accountsMaster = [
  "Adani Gas",
  "AMC",
  "Credit Card",
  "Electricity",
  "FD/ Investment",
  "LIC",
  "Mobile/ Internet Connection",
  "Rent",
];
