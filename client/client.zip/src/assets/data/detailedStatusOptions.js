export const detailedStatusOptions = [
  { id: 1, name: "Select Status", value: "all" },
  {
    id: 2,
    name: "Estimated Time of Arrival",
    value: "Estimated Time of Arrival",
  },
  { id: 3, name: "Gateway IGM Filed", value: "Gateway IGM Filed" },
  {
    id: 4,
    name: "Discharged",
    value: "Discharged",
  },
  {
    id: 5,
    name: "BE Noted, Arrival Pending",
    value: "BE Noted, Arrival Pending",
  },
  {
    id: 6,
    name: "BE Noted, Clearance Pending",
    value: "BE Noted, Clearance Pending",
  },
  {
    id: 7,
    name: "Custom Clearance Completed",
    value: "Custom Clearance Completed",
  },
];
