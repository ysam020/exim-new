import React from "react";

function Packages() {
  return <div>Packages</div>;
}

export default Packages;
