import React from "react";

function Bulk() {
  return <div>Bulk</div>;
}

export default Bulk;
