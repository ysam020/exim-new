import React from "react";

function Container() {
  return <div>Container</div>;
}

export default Container;
